'use client'

export function useResume() {
  // Configure your resume URL here - can be:
  // - Google Drive: https://drive.google.com/uc?id=FILE_ID&export=download
  // - Vercel Blob: https://your-project.blob.vercel-storage.com/resume.pdf
  // - Any public URL to your PDF
  const resumeUrl = process.env.NEXT_PUBLIC_RESUME_URL || '/resume.pdf'
  
  const handleDownload = () => {
    // Create a download link and trigger it
    const link = document.createElement('a')
    link.href = resumeUrl
    link.download = 'Ayswarya_Kurup_Resume.pdf'
    link.target = '_blank'
    link.rel = 'noopener noreferrer'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return { resumeUrl, isLoading: false, handleDownload }
}
