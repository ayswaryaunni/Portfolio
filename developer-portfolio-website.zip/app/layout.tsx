import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import './globals.css'

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] })
const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
})

export const metadata: Metadata = {
  title: 'Ayswarya K - Software Engineer',
  description: 'Software Engineer specializing in ERPNext, React, and full-stack development. Building enterprise ERP solutions and modern web applications.',
  keywords: 'Software Engineer, ERPNext, Frappe, React, Next.js, Full Stack Developer',
  authors: [{ name: 'Ayswarya K' }],
  openGraph: {
    title: 'Ayswarya K - Software Engineer',
    description: 'Building enterprise ERP solutions and modern web & mobile applications',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0B1120',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable} dark scroll-smooth`}>
      <body className="font-sans antialiased bg-background text-foreground">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
