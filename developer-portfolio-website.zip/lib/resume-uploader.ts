'use server'

import { put } from '@vercel/blob'
import { readFileSync } from 'fs'
import { join } from 'path'

export async function uploadResumeToBlobOnce() {
  // Only upload once during deployment
  // In production, this blob URL will be cached
  try {
    // Check if we already have a blob URL stored in environment
    if (process.env.NEXT_PUBLIC_RESUME_BLOB_URL) {
      return process.env.NEXT_PUBLIC_RESUME_BLOB_URL
    }

    // Read the resume PDF from the public folder (will be copied there during build)
    const publicPath = join(process.cwd(), 'public', 'resume.pdf')
    const fileBuffer = readFileSync(publicPath)

    // Upload to Vercel Blob
    const blob = await put('resume.pdf', fileBuffer, {
      access: 'public',
      contentType: 'application/pdf',
    })

    return blob.url
  } catch (error) {
    console.error('[v0] Error uploading resume:', error)
    return null
  }
}
