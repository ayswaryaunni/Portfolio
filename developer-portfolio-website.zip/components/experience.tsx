'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

export function Experience() {
  const { ref, inView } = useInView({
    threshold: 0.2,
    triggerOnce: true,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.6 },
    },
  }

  const experiences = [
    {
      title: 'Software Engineer',
      company: 'Innogenio Solutions',
      period: 'Nov 2022 - Present',
      responsibilities: [
        'Develop enterprise ERP solutions using ERPNext and Frappe Framework',
        'Build React.js, Next.js and React Native applications',
        'Develop workflow automation and REST APIs',
        'Implement GraphQL integrations and OAuth',
        'Integrate OpenAI and Azure Document Intelligence',
        'Design responsive UI components and systems',
      ],
    },
  ]

  return (
    <section id="experience" className="py-24 px-6 bg-white/2" ref={ref}>
      <div className="max-w-4xl mx-auto">
        <motion.h2
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-16 text-white"
        >
          Experience
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="space-y-8"
        >
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="glass p-8 rounded-xl border-l-2 border-blue-500 hover:border-purple-500 transition-all duration-300"
            >
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold text-white mb-1">
                    {exp.title}
                  </h3>
                  <p className="text-blue-400 font-medium">
                    {exp.company}
                  </p>
                </div>
                <p className="text-gray-400 text-sm mt-2 md:mt-0">
                  {exp.period}
                </p>
              </div>

              <ul className="space-y-2 mt-6">
                {exp.responsibilities.map((resp, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-gray-300">
                    <span className="text-purple-400 mt-1 flex-shrink-0">→</span>
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
