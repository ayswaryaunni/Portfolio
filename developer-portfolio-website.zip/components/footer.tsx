'use client'

import { motion } from 'framer-motion'

export function Footer() {
  return (
    <footer className="border-t border-white/10 py-8 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col md:flex-row items-center justify-between gap-4"
        >
          <p className="text-gray-400 text-sm">
            © 2024 Ayswarya K. All rights reserved.
          </p>
          <p className="text-gray-500 text-sm">
            Designed and Developed with <span className="text-purple-400">♥</span> using Next.js, React & Tailwind CSS
          </p>
        </motion.div>
      </div>
    </footer>
  )
}
