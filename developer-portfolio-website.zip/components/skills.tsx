'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import {
  Database,
  Code2,
  Zap,
  Wrench,
  Brain,
} from 'lucide-react'

export function Skills() {
  const { ref, inView } = useInView({
    threshold: 0.2,
    triggerOnce: true,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const skillCategories = [
    {
      icon: Zap,
      title: 'ERP',
      skills: ['ERPNext', 'Frappe Framework', 'Workflow Automation'],
    },
    {
      icon: Code2,
      title: 'Frontend',
      skills: ['React.js', 'Next.js', 'React Native', 'TailwindCSS'],
    },
    {
      icon: Database,
      title: 'Backend',
      skills: ['Python', 'Node.js', 'NestJS', 'REST APIs', 'GraphQL'],
    },
    {
      icon: Database,
      title: 'Database',
      skills: ['MariaDB', 'PostgreSQL', 'Supabase', 'Firebase'],
    },
    {
      icon: Brain,
      title: 'AI/ML',
      skills: ['OpenAI API', 'Azure Document Intelligence', 'TensorFlow'],
    },
    {
      icon: Wrench,
      title: 'Tools',
      skills: ['Git', 'GitHub', 'Jira', 'Figma', 'Postman'],
    },
  ]

  return (
    <section id="skills" className="py-24 px-6 bg-white/2" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-16 text-white"
        >
          Skills & Technologies
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {skillCategories.map((category, index) => {
            const IconComponent = category.icon
            return (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ scale: 1.05 }}
                className="glass p-8 rounded-xl group hover:bg-white/10 transition-all duration-300"
              >
                <div className="flex items-start gap-4 mb-6">
                  <div className="p-3 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-lg group-hover:from-blue-500/30 group-hover:to-purple-500/30 transition-all">
                    <IconComponent className="text-blue-400 group-hover:text-purple-400 transition-colors" size={24} />
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-blue-300 transition-colors">
                    {category.title}
                  </h3>
                </div>

                <ul className="space-y-2">
                  {category.skills.map((skill, idx) => (
                    <li
                      key={idx}
                      className="flex items-center gap-2 text-gray-300 text-sm group-hover:text-gray-200 transition-colors"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-blue-400 to-purple-400" />
                      {skill}
                    </li>
                  ))}
                </ul>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
