'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Share2, Link as LinkIcon, Mail } from 'lucide-react'

export function Contact() {
  const { ref, inView } = useInView({
    threshold: 0.3,
    triggerOnce: true,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const socialLinks = [
    {
      icon: Mail,
      label: 'Email',
      href: 'mailto:hello@example.com',
      color: 'hover:text-purple-400',
    },
    {
      icon: LinkIcon,
      label: 'LinkedIn',
      href: 'https://linkedin.com',
      color: 'hover:text-blue-400',
    },
    {
      icon: Share2,
      label: 'GitHub',
      href: 'https://github.com',
      color: 'hover:text-white',
    },
  ]

  return (
    <section id="contact" className="py-24 px-6" ref={ref}>
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
        >
          <motion.h2
            variants={itemVariants}
            className="text-4xl md:text-5xl font-bold mb-6 text-white"
          >
            Let&apos;s Build Something Amazing Together
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-gray-400 text-lg mb-12 max-w-2xl mx-auto"
          >
            I&apos;m always interested in hearing about new projects and opportunities. Feel free to reach out!
          </motion.p>



          {/* Social links */}
          <motion.div
            variants={itemVariants}
            className="flex justify-center gap-8"
          >
            {socialLinks.map((link, index) => {
              const IconComponent = link.icon
              return (
                <motion.a
                  key={index}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1, y: -5 }}
                  className={`p-4 glass rounded-full text-gray-400 transition-all duration-200 ${link.color}`}
                  aria-label={link.label}
                >
                  <IconComponent size={24} />
                </motion.a>
              )
            })}
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
