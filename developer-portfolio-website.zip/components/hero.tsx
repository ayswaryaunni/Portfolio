'use client'

import { motion } from 'framer-motion'
import { ArrowDown } from 'lucide-react'

export function Hero() {

  const handleScrollDown = () => {
    const aboutSection = document.getElementById('about')
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20 px-6 relative overflow-hidden">
      {/* Gradient background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-72 h-72 bg-blue-500/10 rounded-full filter blur-3xl" />
        <div className="absolute bottom-40 left-10 w-72 h-72 bg-purple-500/10 rounded-full filter blur-3xl" />
      </div>

      <motion.div
        className="max-w-4xl mx-auto text-center relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Main heading */}
        <motion.h1
          variants={itemVariants}
          className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-blue-200 to-purple-400 bg-clip-text text-transparent"
        >
          Ayswarya K
        </motion.h1>

        {/* Title */}
        <motion.h2
          variants={itemVariants}
          className="text-2xl md:text-3xl font-semibold text-gray-300 mb-4"
        >
          Software Engineer
        </motion.h2>

        {/* Subtitle */}
        <motion.p
          variants={itemVariants}
          className="text-base md:text-lg text-gray-400 mb-8 max-w-2xl mx-auto"
        >
          ERPNext Developer • Frappe Framework • React.js • Next.js • React Native
        </motion.p>

        {/* Description */}
        <motion.p
          variants={itemVariants}
          className="text-gray-400 mb-12 max-w-3xl mx-auto text-base leading-relaxed"
        >
          Building enterprise ERP solutions and modern web & mobile applications with clean architecture, scalable code, and intuitive user experiences.
        </motion.p>



        {/* Scroll indicator */}
        <motion.button
          onClick={handleScrollDown}
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex justify-center mx-auto cursor-pointer hover:text-gray-300 transition-colors duration-200"
          aria-label="Scroll down"
        >
          <ArrowDown size={24} className="text-gray-500" />
        </motion.button>
      </motion.div>
    </section>
  )
}
