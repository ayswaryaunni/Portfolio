'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { ExternalLink } from 'lucide-react'

export function Projects() {
  const { ref, inView } = useInView({
    threshold: 0.1,
    triggerOnce: true,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  const projects = [
    {
      title: 'ELNOTE ERP',
      description: 'Enterprise ERP system for packaging industry with advanced inventory management and reporting',
      tags: ['ERPNext', 'Frappe', 'Python', 'React'],
    },
    {
      title: 'Packaging ERP',
      description: 'Specialized ERP solution for packaging manufacturers with workflow automation',
      tags: ['ERPNext', 'Frappe', 'API Integration'],
    },
    {
      title: 'Seguros',
      description: 'Insurance management platform with real-time policy tracking and claims processing',
      tags: ['Next.js', 'React', 'PostgreSQL', 'Stripe'],
    },
    {
      title: 'Cine App',
      description: 'Mobile application for cinema ticket booking with real-time seat selection',
      tags: ['React Native', 'Node.js', 'Firebase'],
    },
    {
      title: 'Holistics AI',
      description: 'AI-powered analytics dashboard with machine learning insights and data visualization',
      tags: ['React', 'Python', 'TensorFlow', 'D3.js'],
    },
    {
      title: 'House of Magnets',
      description: 'E-commerce platform for magnetic products with advanced filtering and recommendations',
      tags: ['Next.js', 'Shopify API', 'TailwindCSS'],
    },
  ]

  return (
    <section id="projects" className="py-24 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          variants={itemVariants}
          className="text-4xl md:text-5xl font-bold mb-16 text-white"
        >
          Featured Projects
        </motion.h2>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              whileHover={{ y: -5 }}
              className="glass p-6 rounded-xl group hover:bg-white/10 transition-all duration-300 cursor-pointer"
            >
              {/* Project header */}
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold text-white group-hover:text-blue-300 transition-colors">
                  {project.title}
                </h3>
                <ExternalLink
                  size={20}
                  className="text-gray-400 group-hover:text-blue-400 transition-colors flex-shrink-0"
                />
              </div>

              {/* Description */}
              <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                {project.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-300 rounded-full border border-blue-500/30 group-hover:border-purple-500/50 transition-colors"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
